package loops;

public class Example10 {

	public static void main(String[] args) {
do{
	System.out.println("out");
}
	while(true);
	
}
	}


