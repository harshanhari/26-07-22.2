package interfaceExamples;

public interface Printable1 {
void print();
}
