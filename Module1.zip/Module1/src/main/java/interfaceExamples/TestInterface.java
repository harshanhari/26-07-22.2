package interfaceExamples;

public class TestInterface implements Printable2,Drawable2{

	public static void main(String[] args) {
TestInterface t=new TestInterface();
t.print();
	}


	@Override
	public void print() {
System.out.println("Hello");		
	}


}
