package interfaceExamples;

public class SBI implements Bank{

	@Override
	public float roi() {
	return 7.3f;// TODO Auto-generated method stub
		
	}

}
