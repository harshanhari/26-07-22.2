package interfaceExamples;

public interface Drawable2 {
void print();
}
