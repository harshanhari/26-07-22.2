package interfaceExamples;

public class TestBank {

	public static void main(String[] args) {
Bank b1=new SBI();
System.out.println("The roi of SBI is "+b1.roi());
	}
	

}
