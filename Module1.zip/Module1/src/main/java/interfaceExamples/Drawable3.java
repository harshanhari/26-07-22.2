package interfaceExamples;

public interface Drawable3 extends Printable3{
void draw();
}
