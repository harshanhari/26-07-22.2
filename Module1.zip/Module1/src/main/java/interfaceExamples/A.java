package interfaceExamples;

public class A implements Printable{
public void print() {
	System.out.println("Hello");
}
	public static void main(String[] args) {
	A a=new A();
	a.print();// TODO Auto-generated method stub

	}

}
