package interfaceExamples;

public class TestDraw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Drawable d1,d2;
d1=new Circle();
d2=new Rectangle();
d1.draw();
d2.draw();
	}

}
