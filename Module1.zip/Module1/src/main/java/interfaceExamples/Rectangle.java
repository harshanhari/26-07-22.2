package interfaceExamples;

public class Rectangle implements Drawable{

	@Override
	public void draw() {
System.out.println("Rectangle");		
	}

}
