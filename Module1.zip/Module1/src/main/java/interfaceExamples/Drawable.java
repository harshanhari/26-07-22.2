package interfaceExamples;

public interface Drawable {
void draw();
}
