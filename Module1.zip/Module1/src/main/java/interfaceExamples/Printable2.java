package interfaceExamples;

public interface Printable2 {
void print();
}
