package interfaceExamples;

public interface Printable3 {
void print();
}
