package interfaceExamples;

public class Circle implements Drawable{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Circle");
	}

}
