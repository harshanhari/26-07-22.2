package interfaceExamples;

public class PNB implements Bank{

	@Override
	public float roi() {
		// TODO Auto-generated method stub
		return 9.6f;
	}

}
