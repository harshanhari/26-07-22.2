package interfaceExamples;

public interface Bank {
float roi();
}
