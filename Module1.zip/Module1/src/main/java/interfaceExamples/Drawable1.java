package interfaceExamples;

public interface Drawable1 {
void draw();
}
