package interfaceExamples;

public class A1 implements Printable1,Drawable1{

	public static void main(String[] args) {
A1 a=new A1();
a.print();
a.draw();
	}

	@Override
	public void draw() {
System.out.println("Hello");		
	}

	@Override
	public void print() {
System.out.println("Welcome");		
	}

}
