package interfaceExamples;

public class Test implements Drawable3 {

	public static void main(String[] args) {
Test t=new Test();
t.print();
t.draw();
	}

	@Override
	public void print() {
System.out.println("Printing");		
	}

	@Override
	public void draw() {
System.out.println("Drawing");		
	}

}
