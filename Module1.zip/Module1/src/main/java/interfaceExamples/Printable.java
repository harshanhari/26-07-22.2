package interfaceExamples;

public interface Printable {
void print();
}
