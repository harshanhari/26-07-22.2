package abstraction;

abstract class Shape {
abstract void display();
}
