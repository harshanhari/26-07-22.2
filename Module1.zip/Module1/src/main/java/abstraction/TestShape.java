package abstraction;

public class TestShape {

	public static void main(String[] args) {
Shape s1,s2;
s1=new Circle();
s2=new Rectangle();
s1.display();
s2.display();
	}

}
