package abstraction;

public class Rectangle extends Shape{

	@Override
	void display() {
System.out.println("Drawing Rectangle");		
	}

}
