package abstraction;

public class TestBike {

	public static void main(String[] args) {
Bike1 b=new Honda1();
b.run();
b.changeGear();
	}

}
