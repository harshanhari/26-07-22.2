package abstraction;

abstract class Bike {
abstract void run();
}
