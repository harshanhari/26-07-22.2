package abstraction;

public class SBI extends Bank {
int roi() {
	return 7;
}
}
