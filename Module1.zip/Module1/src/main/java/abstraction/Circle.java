package abstraction;

public class Circle extends Shape{

	@Override
	void display() {
		// TODO Auto-generated method stub
		System.out.println("Drawing circle");
	}

}
