package abstraction;

public class AXIS extends Bank{
	int roi() {
		return 8;
	}

}
