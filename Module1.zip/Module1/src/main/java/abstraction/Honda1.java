package abstraction;

public class Honda1 extends Bike1{
void run() {
	System.out.println("Bike is running");
}
}
