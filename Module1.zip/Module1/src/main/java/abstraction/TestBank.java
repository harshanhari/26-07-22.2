package abstraction;

public class TestBank {

	public static void main(String[] args) {
Bank b1=new SBI();
System.out.println("The rate of intrest of SBI is "+b1.roi());
Bank b2=new AXIS();
System.out.println("The rate of intrest of AXIS is "+b2.roi());
	}

}
