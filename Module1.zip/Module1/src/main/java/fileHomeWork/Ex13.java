package fileHomeWork;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Ex13 {

	public static void main(String[] args) {

		try {
			File f10 = new File("doc.txt");
			Scanner sc = new Scanner(f10);
			System.out.println(sc.nextLine());

		} catch (Exception e) {
			e.getStackTrace();
		}

	}

}
