package fileHomeWork;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Ex15 {

	public static void main(String[] args) {

		try {
			File f1 = new File("doc.txt");
//			Sca
			
			
		} catch (Exception e) {
			e.getStackTrace();// TODO: handle exception
		}
	}

}
