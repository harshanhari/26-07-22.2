package exception;

public class Eg2 {

	public static void main(String[] args) {

		int d;
		try {
			d=50/0;
		}catch (Exception e) {
			// TODO: handle exception

System.out.println("error");

		}
		
		// TODO Auto-generated method stub
	}

}
