package exception;

public class Eg4 {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		try {
int arr[]= {1,2,3,4,5};
arr[10]=30/0;
System.out.println(arr[20]);
		}catch (ArithmeticException e) {
			System.out.println("Arithmetic Exception occur ");// TODO: handle exception
		}catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
System.out.println("ArrayIndexOutOfBounds Exception occur");
		}catch (Exception e) {
			System.out.println("Parent Exception occur");
			// TODO: handle exception
		}
		System.out.println("Programming is running");
	}

}
