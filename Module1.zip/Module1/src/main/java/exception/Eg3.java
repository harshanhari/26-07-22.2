package exception;

public class Eg3 {

	public static void main(String[] args) {
		int i = 50;
		int j = 0;
		int d, f;
		try {
			int k = i / j;
		} catch (Exception e) {
			d = j / i;
			f = i / (j + 2);
			System.out.println(d);
			System.out.println(f);
		}
		System.out.println("Error");

	}

}
