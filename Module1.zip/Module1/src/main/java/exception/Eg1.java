package exception;

public class Eg1 {

	public static void main(String[] args) {
	
		try {
			int d = 100 / 10;

		} catch (ArithmeticException e) {
			// TODO: handle exception

		} finally {
			System.out.println("final");
		}
		System.out.println(" output");
	}

}
