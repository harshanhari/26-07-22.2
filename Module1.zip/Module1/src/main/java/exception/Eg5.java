package exception;

public class Eg5 {

	public static void main(String[] args) {

		try {
			try {
			 System.out.println("Dividing by 0");
	int d=30/0;	
			}catch (ArithmeticException e) {
				// TODO: handle exception
				System.out.println(e);
			}
			try {
				int a[]=new int[5];
			a[5]=4;
			System.out.println(a[5]);
			}catch (ArrayIndexOutOfBoundsException e) {
				// TODO: handle exception
				System.out.println(e);
			}
			System.out.println("Running");
		}catch (Exception e) {
			System.out.println("Non");
			// TODO: handle exception
		}
		System.out.println("Prgm exicuting");
		
	}

}
