package connection;

import java.sql.*;
import java.util.Scanner;

public class FetchRecord {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose your operation : Insert or Update or Delete or PrintLine or DisplayContent");
		String query = sc.nextLine();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://192.168.18.245:3306/javadb_167", "javadb_167",
					"ben#u62000");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * from Emp2");

			switch (query) {
			case "Insert": {
				int result = stmt.executeUpdate("INSERT into Emp2 values(101,'Nandhu',14000)");
				System.out.println("INSERTED");
				break;
			}
			case "Update": {
				int result = stmt.executeUpdate("UPDATE Emp2 set name='Akhil',salary =22000 WHERE id=101");
				System.out.println("UPDATED");
				break;
			}
			case "Delete": {
				int result = stmt.executeUpdate("DELETE from Emp2 WHERE id=101");
				System.out.println("DELETED");
				break;
			}
			case "PrintLine" : {
				System.out.println("Enter the line number : ");
				int line=sc.nextInt();
				rs.relative(line);
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
			break;
			}
			case "DisplayContent" : {
				while(rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
				}
			}
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);// TODO: handle exception
		}

	}
}