package overriding;

public class Bike extends Vehicle{

	public static void main(String[] args) {
Bike obj=new Bike();
obj.run();
	}

}
