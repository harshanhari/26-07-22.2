package overriding;

public class ICICI {
int rateOfIntrest() {
	return 8;
}
}
