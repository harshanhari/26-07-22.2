package overriding;

public class Vehicle {
void run() {
	System.out.println("bike is running");
}
}
