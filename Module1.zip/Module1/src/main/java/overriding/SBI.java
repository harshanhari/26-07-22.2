package overriding;

public class SBI {
int rateOfIntrest() {
	return 7;
}
}
