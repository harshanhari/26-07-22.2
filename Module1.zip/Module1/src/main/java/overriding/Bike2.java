package overriding;

public class Bike2 {
void run() {
	System.out.println("bike is running safely");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bike2 ob=new Bike2();
ob.run();
	}

}
