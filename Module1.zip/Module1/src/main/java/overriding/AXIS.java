package overriding;

public class AXIS {
int rateOfIntrest() {
	return 9;
}
}
