package overriding;

public class TestOR {

	public static void main(String[] args) {
SBI s=new SBI();
ICICI i=new ICICI();
AXIS a=new AXIS();
System.out.println("Intrest of SBI is "+s.rateOfIntrest());
System.out.println("Intrest of ICICI is "+i.rateOfIntrest());
System.out.println("Intrest of AXIS is "+a.rateOfIntrest());

	}

}
