package overriding;

public class Bank {
int rateOfIntrest() {
	return 0;
}
}
