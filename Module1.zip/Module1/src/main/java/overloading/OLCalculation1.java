package overloading;

public class OLCalculation1 {
void sum(int a,long b) {
	System.out.println(a+b);
}
void sum(int a,int b,int c) {
	System.out.println(a+b+c);
}
	public static void main(String[] args) {
OLCalculation1 ob=new OLCalculation1();
ob.sum(20,20);
ob.sum(20,20,20);
	}

}
