package overloading;

public class TestOL2 {

	public static void main(String[] args) {
		System.out.println("with array args");
		// TODO Auto-generated method stub

	}
	public static void main(String args) {
		System.out.println("without out array args ");
	}
	public static void main() {
		System.out.println("nothing");
	}
}
