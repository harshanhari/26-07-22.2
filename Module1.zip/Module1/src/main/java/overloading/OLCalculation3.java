package overloading;

public class OLCalculation3 {
void add(long a,int b) {
	System.out.println("A invoked");
}
void add(int a,long b) {
	System.out.println("B invoked");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
OLCalculation3 ob3=new OLCalculation3();
//ob3.add(20, 20);// error
	}

}
