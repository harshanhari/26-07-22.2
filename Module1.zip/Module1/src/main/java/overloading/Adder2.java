package overloading;

/*public class Adder2 {
static int add(int a,int b) {
	return a+b;
}
static double add(int a,int b) {
	return a+b;
}
}
*/