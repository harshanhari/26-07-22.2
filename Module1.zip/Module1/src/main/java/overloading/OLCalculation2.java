package overloading;

public class OLCalculation2 {
void add(int a,int b) {
	System.out.println("int arg invoked");
}
void add(long a,long b) {
	System.out.println("long arg invoked");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
OLCalculation2 ob1=new OLCalculation2();
ob1.add(20,20);
	}

}
