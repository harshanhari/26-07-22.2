package string;

public class Eg4 {

	public static void main(String[] args) {
	String s1="Sachin";
	String s2="Sachin";
	String s3="SACHIN";
	String s4=new String("Sachin");
	String s5="Sourav";
	String s=40+40+"SACHIN"+40+40;/*numbers after char initialization are concat together like 80SACHIN4040 */
	System.out.println(s1.equals(s2));
	System.out.println(s1.equals(s3));
	System.out.println(s3.equals(s4));
	System.out.println(s1.equalsIgnoreCase(s2));
	System.out.println(s1==s2);
	System.out.println(s1==s4);
	System.out.println(s1.compareTo(s2));
	System.out.println(s1.compareTo(s5));
	System.out.println(s1.concat(s5));
	System.out.println(s);
	System.out.println(s1.substring(3,4));
    System.out.println(s1.toCharArray());
    
	}
	
}
