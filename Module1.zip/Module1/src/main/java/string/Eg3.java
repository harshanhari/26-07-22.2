package string;

public class Eg3 {

	public static void main(String[] args) {
String s1="Sachin";
s1.concat("Tentulker");

System.out.println(s1);
	}

}
