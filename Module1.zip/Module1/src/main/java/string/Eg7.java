package string;

public class Eg7 {

	public static void main(String[] args) {
StringBuilder s=new StringBuilder("Hello");
System.out.println(s.capacity());
s.append("Java");
System.out.println(s);	
s.insert(1,"Again" );
System.out.println(s);
s.replace(0, 20, "With");
System.out.println(s);
	s.delete(1, 3);
	System.out.println(s);
s.append("ere are you my boy");
System.out.println(s);
s.reverse();
System.out.println(s);
s.reverse();
System.out.println(s);
System.out.println(s.capacity());
s.append(". You know, java is my favourite language");
System.out.println(s);
System.out.println(s.capacity());
s.ensureCapacity(10);
System.out.println(s.capacity());

StringBuilder s1=new StringBuilder();
System.out.println(s1.capacity());

	}

}
