package string;

public class Eg1 {

	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "Welcome";
		System.out.println(s1.charAt(2));
		System.out.println(s1.indexOf('e'));
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.equals(s2));
		System.out.println(s1.length());
		System.out.println(s1.lastIndexOf('l'));
		System.out.println(s1.codePointAt(2));
		System.out.println(s1.concat(s2));
		System.out.println(s1.contains("l"));
		System.out.println(s1.endsWith("lo"));
		System.out.println(s1.isEmpty());
		System.out.println(s1.replace("e","s"));
		System.out.println(s1.trim());
	}

}
