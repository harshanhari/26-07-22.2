package string;

public class Eg2 {

	public static void main(String[] args) {
String s1="Java";
char ch[]= {'a','b','c'};
String s2=new String(ch);
String s3=new String("Hai");
System.out.println(s1+"\n"+s2+"\n"+s3);
	}
}
