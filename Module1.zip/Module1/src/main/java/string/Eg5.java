package string;

import java.util.Arrays;

public class Eg5 {

	public static void main(String[] args) {
String s1="Hai, My name is Harshan Hari.";
String arr[]=s1.split("\\.");
System.out.println(Arrays.toString(arr));

}
}