package string;

public class Eg6 {

	public static void main(String[] args) {
String s="Sachin";
System.out.println(s.startsWith("Sa"));
System.out.println(s.endsWith("n"));
System.out.println(s.contains("c"));
	}

}
