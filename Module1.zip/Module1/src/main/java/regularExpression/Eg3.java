package regularExpression;

import java.util.regex.Pattern;

public class Eg3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Pattern.matches("[amn]", "abcd"));
		System.out.println(Pattern.matches("[amn]", "a"));
		System.out.println(Pattern.matches("[amn]", "ammmn"));
		System.out.println(Pattern.matches("[^amn]", "b"));
		System.out.println(Pattern.matches("[a-zA-Z]", "S"));
		System.out.println(Pattern.matches("[a-d[m-p]]", "e"));
		System.out.println(Pattern.matches("[a-z&&[def]]", "e"));
		System.out.println(Pattern.matches("[a-z&&[^bc]]", "c"));
		System.out.println(Pattern.matches("[a-z&&[^m-p]]", "l"));

	}

}
