package assignment5;

public class TestCylinder {

	public static void main(String[] args) {
		Circle c2=new Circle(5);
		Cylinder c1=new Cylinder(5,10);
System.out.println(c1.getVolume());
System.out.println(c2.getArea());
	}

}
