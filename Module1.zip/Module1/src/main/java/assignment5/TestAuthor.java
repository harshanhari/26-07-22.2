package assignment5;

public class TestAuthor {

	public static void main(String[] args) {
		Author a1 = new Author("Roberto Carlos", "carlos2022@gmail.com", 'm');
		System.out.println(a1.toString());

	}

}
