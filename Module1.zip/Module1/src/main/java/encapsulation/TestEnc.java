package encapsulation;

import java.time.temporal.TemporalAmount;

public class TestEnc {

	public static void main(String[] args) {
Account a1=new Account();
a1.setAcc_no(3527238423982356l);
a1.setName("Harshan Hari");
a1.setEmail("harshanharijithu@gmail.com");
a1.setAmnt(8600000f);
System.out.println(a1.getAcc_no()+" "+a1.getName()+" "+a1.getEmail()+" "+a1.getAmnt());
	}

}
