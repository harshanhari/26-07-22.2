package encapsulation;

public class Test {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setName("Arun");
		System.out.println("The name is " + s1.getName());
	}

}
