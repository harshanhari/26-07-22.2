package encapsulation;

public class Student2 {
private String college;
void setCollege(String college) {
	this.college=college;
}
public static void main(String[] args) {
	Student2 s2=new Student2();
	//System.out.println(s2.getCollege);
	System.out.println(s2.college);
}
}
