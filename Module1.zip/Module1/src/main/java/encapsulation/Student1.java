package encapsulation;

public class Student1 {
private String college="AKG";

public String getCollege() {
	return college;
}
public static void main(String[] args) {
	Student1 s=new Student1();
	//s1.setCollege("KIT")
}

}
