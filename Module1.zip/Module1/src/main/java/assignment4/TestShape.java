package assignment4;

public class TestShape {

	public static void main(String[] args) {
		Rectangle r = new Rectangle();
		System.out.println(r.getArea(10, 20));
		Triangle t = new Triangle();
		System.out.println(t.getArea(10, 20));
		System.out.println(r);
		System.out.println(t);

	}

}
