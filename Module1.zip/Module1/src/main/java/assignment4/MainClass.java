package assignment4;

public class MainClass implements Inter1,Inter2{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
MainClass c=new MainClass();
c.display();
c.print();
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Displaying");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Printing");
	}

}
