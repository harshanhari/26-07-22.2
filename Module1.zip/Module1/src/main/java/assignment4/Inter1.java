package assignment4;

public interface Inter1 {
void print();
}
