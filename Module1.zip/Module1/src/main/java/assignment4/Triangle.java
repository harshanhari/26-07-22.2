package assignment4;

public class Triangle extends Shape {
	float base, hight;

	@Override
	float getArea(float base, float hight) {
		this.base = base;
		this.hight = hight;
		return (base * hight) / 2;
	}

	@Override
	public String toString() {
		return "Triangle [base=" + base + ", hight=" + hight + "]";
	}
}
