package assignment4;

public class Shape {
	String color;

	float getArea(float a, float b) {
		return 0.0f;
	}

	@Override
	public String toString() {
		return "Shape [color=" + color + "]";
	}

}
