package assignment4;

public class ToTestInt extends Arithmetic{
 void give() {
		System.out.println("Giving output");
	}
public static void main(String[] args) {
	Arithmetic b=new Arithmetic();
	b.square();
}
}

