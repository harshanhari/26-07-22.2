package assignment4;

public class Outer {
void display() {
	System.out.println("Displaying Outer function");
}
}
