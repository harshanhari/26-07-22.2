package assignment4;

public interface Inter2 {
void display();
}
