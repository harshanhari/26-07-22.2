package assignment4;

public interface Test {
void square();
}
