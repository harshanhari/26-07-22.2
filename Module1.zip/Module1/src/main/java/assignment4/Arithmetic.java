package assignment4;

public class Arithmetic implements Test {

	public static void main(String[] args) {
	    Arithmetic a= new Arithmetic();
		a.square();
	}

	@Override
	public void square() {
System.out.println("You are using square function");		
	}



}
