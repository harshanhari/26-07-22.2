package assignment4;

public class Rectangle extends Shape {
	float base, width;

	@Override
	float getArea(float base, float width) {
		this.base = base;
		this.width = width;
		return base * width;
	}

	@Override
	public String toString() {
		return "Rectangle [base=" + base + ", width=" + width + "]";
	}
}
