package assignment4;

public class Inner {
void display() {
	System.out.println("Displaying inner function");
}
}
