package pack1;

public class Example1 {

	public static void main(String[] args) {
		int a=10;
		float b=a;
		System.out.println(a+","+b);

	}

}
