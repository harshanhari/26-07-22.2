package pack1;

public class Example3 {

	public static void main(String[] args) {
int a=123;
byte b=(byte) a;
	System.out.println(a+","+b);
	}

}
