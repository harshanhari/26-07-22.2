package collections;

public class Book {

	int id;
	String author, name, publisher;
	int qty;

	public Book(int id, String author, String name, String publisher, int qty) {

		this.id = id;
		this.author = author;
		this.name = name;
		this.publisher = publisher;
		this.qty = qty;

	}

	public int compareTo(Book b) {
		if (id > b.id) {
			return 1;
		} else if (id < b.id) {
			return -1;
		} else {
			return 0;
		}
	}
}
