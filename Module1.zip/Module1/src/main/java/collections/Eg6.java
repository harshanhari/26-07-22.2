package collections;

import java.util.*;

public class Eg6 {

	public static void main(String[] args) {

		List<Book> l1 = new ArrayList<Book>();
		Book b1 = new Book(101, "Let us C", "Yash kahn", "Abc", 8);
		Book b2 = new Book(102, "Data communication and networking", "Foruizen", "Def", 4);
		Book b3 = new Book(103, "Operating system", "Galvin", "Ghi", 6);
		l1.add(b1);
		l1.add(b2);
		l1.add(b3);
		for (Book b : l1) {
			System.out.println(b.id + " " + b.name + " " + b.author + " " + b.publisher + " " + b.qty);
		}
		System.out.println(l1.size());

	}

}
