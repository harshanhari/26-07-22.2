package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Eg3 {

	public static void main(String[] args) {

		ArrayList<String> al = new ArrayList<String>();
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ravi");
		al.add("Ajay");
		System.out.println("Traversing list through List Iterator : ");
		ListIterator<String> l1 = al.listIterator(al.size());
		while (l1.hasNext()) {
			String str = l1.previous();
			System.out.println(str);
		}
		System.out.println("Traversing list through for loop : ");
		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i));
		}
		System.out.println("Traversing list through for each method : ");
		al.forEach(a -> {
			System.out.println(a);
		});
		System.out.println("Traversing list through for each remaining method : ");
		Iterator<String> itr = al.iterator();
		itr.forEachRemaining(a -> {
			System.out.println(a);
		});
	}

}
