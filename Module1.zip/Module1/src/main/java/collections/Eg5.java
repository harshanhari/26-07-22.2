package collections;

import java.util.*;

public class Eg5 {

	public static void main(String[] args) {

		ArrayList<String> a1 = new ArrayList<String>();
		System.out.println("Initial list of elements : " + a1);
		a1.add("Ravi");
		a1.add("Vijay");
		a1.add("ajay");
		System.out.println("After adding elements : " + a1);
		a1.add("Gaurav");
		System.out.println("After adding one more element : " + a1);
		ArrayList<String> a2 = new ArrayList<String>();
		a2.add("Sonoo");
		a2.add("Hanumat");
		a1.addAll(a2);
		System.out.println("After adding 2 list : " + a1);
		ArrayList<String> a3 = new ArrayList<String>();
		a3.add("John");
		a3.add("Rahul");
		a1.addAll(a3);
		System.out.println("After adding the lst list : " + a1);
		a1.remove("Vijay");
		System.out.println("After removing : " + a1);
		a1.remove(0);
		System.out.println(a1);
		System.out.println(a1);
		a1.removeIf(str -> str.contains("Ajay"));
		System.out.println(a1);
		a1.retainAll(a2);
		System.out.println(a1);
	System.out.println(a1.isEmpty());
	}

}
