package collections;

import java.util.*;

public class Eg7 {

	public static void main(String[] args) {

		LinkedList<String> ll = new LinkedList<String>();
		ll.add("Ravi");
		ll.add("Vijay");
		ll.add("Ravi");
		ll.add("Ajay");
		Iterator<String> itr = ll.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		ll.add(1, "Gaurav");
		System.out.println(ll);
		LinkedList<String> l1 = new LinkedList<String>();
		l1.add("Sonoo");
		l1.add("Hanumat");
		ll.addAll(l1);
		System.out.println(ll);
		LinkedList<String> l2 = new LinkedList<String>();
		l2.add("John");
		l2.add("Rahul");
		ll.addAll(1, l2);
		System.out.println(ll);
		ll.addFirst("Lokesh");
		System.out.println(ll);
		ll.addLast("Harsh");
		System.out.println(ll);
		ll.remove("Vijay");
		System.out.println(ll);
		ll.remove(0);
		System.out.println(ll);
		ll.removeAll(l2);
		System.out.println(ll);
		ll.removeLast();
		System.out.println(ll);
		ll.removeFirst();
		System.out.println(ll);
		ll.removeFirstOccurrence("Gourav");
		System.out.println(ll);
		ll.removeLastOccurrence("Harsh");
		System.out.println(ll);
		Iterator itr1 = ll.descendingIterator();
		while (itr1.hasNext()) {
			System.out.println(itr1.next());
		}

	}

}
