package collections;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

public class StoreData {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://192.168.18.245:3306/javadb_167", "javadb_167",
					"ben#u62000");
			System.out.println("Enter The Operation : Insert/Update/Delete");
			String option = sc.nextLine();
			PreparedStatement pst = con.prepareStatement("insert into Emp2 values(?,?,?)");
			pst.setInt(1, 108);
			pst.setString(2, "Rohan");
			pst.setInt(3, 16000);
			int i = pst.executeUpdate();
			System.out.println(i + " Record inserted");
			con.close();
		} catch (Exception e) {
			System.out.println(e);// TODO: handle exception
		}

	}

}
