package collections;

import java.util.*;

public class Eg9 {

	public static void main(String[] args) {

		HashSet<String> hs = new HashSet<String>();
		hs.add("One");
		hs.add("Two");
		hs.add("Three");
		hs.add("Four");
		hs.add("Five");
		System.out.println(hs);
		HashSet<String> set = new HashSet<String>();
		set.add("Ravi");
		set.add("Vijay");
		set.add("Sumith");
		set.add("Ajay");
		Iterator itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());

		}
		set.remove("Ravi");
		System.out.println(set);
		HashSet<String> set1 = new HashSet<String>();
		set1.add("Arun");
		set1.add("Gaurav");
		set.addAll(set1);
		System.out.println(set);
		set.removeAll(set1);
		System.out.println(set);

	}

}
