package collections;

import java.util.*;

public class Eg11 {

	public static void main(String[] args) {

		LinkedHashSet<String> l1 = new LinkedHashSet<String>();
		l1.add("Ravi");
		l1.add("Vijay");
		l1.add("Ravi");
		l1.add("Ajay");
		System.out.println(l1);
		Iterator itr = l1.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println(l1.remove("Ravi") + " " + l1 + " " + l1.remove("Hai"));

		LinkedHashSet<Book> l2 = new LinkedHashSet<Book>();
		Book b1 = new Book(101, "Let us C", "Yash kahn", "Abc", 8);
		Book b2 = new Book(102, "Data communication and networking", "Foruizen", "Def", 4);
		Book b3 = new Book(103, "Operating system", "Galvin", "Ghi", 6);
		l2.add(b1);
		l2.add(b2);
		l2.add(b3);
		for (Book b : l2) {
			System.out.println(b.id + " " + b.name + " " + b.author + " " + b.publisher + " " + b.qty);
		}

	}

}
