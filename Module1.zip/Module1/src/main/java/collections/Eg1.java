package collections;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;

public class Eg1 {

	public static void main(String[] args) {

		ArrayList<Integer> l1 = new ArrayList<Integer>();
		l1.add(10);
		l1.add(20);
		System.out.println(l1);
		System.out.println();
		for (int i : l1) {
			System.out.println(i);
		}
		System.out.println();
		Iterator i = l1.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println();
		ArrayList<String> l2 = new ArrayList<String>();
		l2.add("Hello");
		l2.add("am");
		l2.add("fine");
		Iterator i0 = l2.iterator();
		while (i0.hasNext()) {
			System.out.println(i0.next());
		}
		System.out.println(l2);
	}

}
