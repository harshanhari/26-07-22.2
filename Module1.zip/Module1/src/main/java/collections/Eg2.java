package collections;

import java.util.*;

public class Eg2 {

	public static void main(String[] args) {

		ArrayList<String> al1 = new ArrayList<String>();
		al1.add("mango");
		al1.add("apple");
		al1.add("banana");
		al1.add("grapes");
		System.out.println(al1);
		Iterator itr = al1.iterator();
		System.out.println();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		for (String fruits : al1) {
			System.out.println(fruits);
		}
		System.out.println();
		System.out.println("Return element : "+al1.get(1));
		al1.set(1,"dates");
		System.out.println();
		System.out.println(al1);
		System.out.println();
		Collections.sort(al1);
		System.out.println(al1);
		System.out.println();
		List<Integer> l1=new ArrayList<Integer>();
		l1.add(2);
		l1.add(11);
		l1.add(51);
		l1.add(1);
		Collections.sort(l1);
		System.out.println(l1);
	}

}
