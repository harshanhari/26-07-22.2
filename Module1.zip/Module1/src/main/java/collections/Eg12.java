package collections;

import java.util.*;

public class Eg12 {

	public static void main(String[] args) {

		TreeSet<String> ts = new TreeSet<String>();
		ts.add("Ravi");
		ts.add("Vijay");
		ts.add("Ravi");
		ts.add("Ajay");
		System.out.println(ts);
		System.out.println("dec order:");
		Iterator itr = ts.descendingIterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		TreeSet<Integer> t1 = new TreeSet<Integer>();
		t1.add(21);
		t1.add(22);
		t1.add(23);
		t1.add(24);
		System.out.println("Lowest value  " + t1.pollFirst());
		System.out.println("Highest value " + t1.pollLast());

		TreeSet<String> t2 = new TreeSet<String>();
		t2.add("A");
		t2.add("B");
		t2.add("C");
		t2.add("D");
		t2.add("E");
		System.out.println("Initial set " + t2);
		System.out.println("Reverse set " + t2.descendingSet());
		System.out.println("Head set " + t2.headSet("C", true));
		System.out.println("Subset " + t2.subSet("A", false, "E", true));
		System.out.println("Tail set " + t2.tailSet("C", false));
		

		System.out.println("Head set " + t2.headSet("C"));
		System.out.println("Subset " + t2.subSet("A","E"));
		System.out.println("Tail set " + t2.tailSet("C"));


	}

}
