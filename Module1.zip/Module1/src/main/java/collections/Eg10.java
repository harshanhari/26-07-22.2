package collections;

import java.util.*;

public class Eg10 {

	public static void main(String[] args) {

		ArrayList<String> a1 = new ArrayList<String>();
		a1.add("Ravi");
		a1.add("Vijay");
		a1.add("Ajay");
		System.out.println(a1);

		HashSet<String> hs = new HashSet<String>(a1);
		hs.add("Gaurav");
		System.out.println(hs);

		HashSet<Book> h1 = new HashSet<Book>();
		Book b1 = new Book(101, "Let us C", "Yash kahn", "Abc", 8);
		Book b2 = new Book(102, "Data communication and networking", "Foruizen", "Def", 4);
		Book b3 = new Book(103, "Operating system", "Galvin", "Ghi", 6);
		h1.add(b1);
		h1.add(b2);
		h1.add(b3);
		for (Book b : h1) {
			System.out.println(b.id + " " + b.name + " " + b.author + " " + b.publisher + " " + b.qty);
		}

	}

}
