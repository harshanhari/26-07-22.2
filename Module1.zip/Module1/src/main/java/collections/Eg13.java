package collections;

import java.util.*;
import java.util.Set;
import java.util.TreeSet;

public class Eg13 {

	public static void main(String[] args) {

		Set<Book> s1 = new TreeSet<Book>();
		Book b1 = new Book(101, "Let us C", "Yash kahn", "Abc", 8);
		Book b2 = new Book(102, "Data communication and networking", "Foruizen", "Def", 4);
		Book b3 = new Book(103, "Operating system", "Galvin", "Ghi", 6);
		s1.add(b1);
		s1.add(b2);
		s1.add(b3);
		for (Book b : s1) {
			System.out.println(b.id + " " + b.name + " " + b.author + " " + b.publisher + " " + b.qty);
		}

	}

}
