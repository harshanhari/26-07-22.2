package assignment2;

import java.util.Scanner;

public class Ques17 {

	public static void main(String[] args) {
Scanner number=new Scanner(System.in);
System.out.println("Enter the 1st number");
int a=number.nextInt();
System.out.println("Enter the 2nd number");
int b=number.nextInt();
int ai,bi;
ai=b;
bi=a;
System.out.println("After swapping 1st number is "+ai+" and 2nd number is "+bi);
	}

}
