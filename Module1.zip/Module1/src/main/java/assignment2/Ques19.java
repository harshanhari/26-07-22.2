package assignment2;

import java.util.Scanner;

public class Ques19 {

	public static void main(String[] args) {
Scanner num=new Scanner(System.in);
System.out.println("Enter the number ");
int n=num.nextInt();
int rev,temp,sum=0,c=0;
temp=n;
while(n>0) {
	rev=n%10;
	sum=sum+(rev*rev*rev);
	n=n/10;

}
if(temp==sum) {
System.out.println("armstrong");
	}
else {
	System.out.println("not armsterong");
}
	}
}
