package assignment2;

public class Ques17b {

	public static void main(String[] args) {

	}

}
