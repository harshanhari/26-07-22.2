package assignment2;

import java.util.Scanner;

public class Ques20 {

	public static void main(String[] args) {
Scanner num=new Scanner(System.in);
System.out.println("Enter the limit");
int n=num.nextInt();
double a=0.0;
while(n>0) {
	a=a + (double)1/n;
	n--;
	
}
System.out.println(a);
	}

}
