package assignment2;

public class Ques12 {

	public static void main(String[] args) {
	for(int i=1;i<=50;i+=2) {
		System.out.println(i);
	}

	}

}
