package assignment2;

import java.util.Scanner;

public class Ques16 {

	public static void main(String[] args) {
Scanner number=new Scanner(System.in);
System.out.println("Enter the number");
int a=number.nextInt();
int b;
for(int i=1;i<=10;i++) {
b=i*a;
System.out.println(a+"x"+i+"="+b);
}

	}

}
