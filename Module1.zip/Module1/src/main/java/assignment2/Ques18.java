package assignment2;

import java.util.Scanner;

public class Ques18 {

	public static void main(String[] args) {
Scanner num=new Scanner(System.in);
System.out.println("Enter the number");
int no=num.nextInt();
int a,b;
if(no>=30) {
a=no/30;
b=no%30;
System.out.println(a+" months and "+b+" days");
}
else {
	System.out.println("enter a valid number");
}
	}

}
