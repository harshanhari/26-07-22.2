package assignment2;

import java.util.Scanner;

public class Ques1 {

	public static void main(String[] args) {
Scanner no=new Scanner(System.in);
System.out.println("Enter a number");
int a=no.nextInt();
if(a>0) {
	System.out.println("positive number");
}
else if(a<0) {
	System.out.println("negative number");

}
else {
	System.out.println("invalid entry");
}
	}

}
