package fileOperation;

import java.io.File;

public class Eg4 {

	public static void main(String[] args) {

		File f0 = new File("doc1.txt");
		if (f0.exists()) {
			System.out.println("The name of the file is : " + f0.getName());
			System.out.println("The absolute path of the file is : " + f0.getAbsolutePath());
			System.out.println("Can writeable : " + f0.canWrite());
			System.out.println("Can readable  : " + f0.canRead());
			System.out.println("The size of the file in bytes is : " + f0.length());
		} else {
			System.out.println("The file doesnot exists");
		}

	}

}
