package fileOperation;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class CreateFile {

	public static void main(String[] args) {

		try {

			File f0 = new File("document1.txt");
			FileWriter f1 = new FileWriter(f0);
			Scanner sc = new Scanner(f0);

			if (f0.createNewFile()) {
				System.out.println("File created");

			} else if (f0.exists()) {

				System.out.println("Existing");
				f1.write("Hello Java");
				System.out.println("name of the file : " + f0.getName());
				System.out.println("Absolute path " + f0.getAbsolutePath());
				System.out.println("Can read " + f0.canRead());
				System.out.println("Can write " + f0.canWrite());
				System.out.println(f0.getCanonicalPath());
				System.out.println(f0.getPath());
				System.out.println(f0.isDirectory());
				System.out.println(f0.list());
				System.out.println(f0.length());
				f1.close();

				while (sc.hasNextLine()) {
					String data = sc.nextLine();
					System.out.println(data);
				}

				sc.close();	
				//f0.delete();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
