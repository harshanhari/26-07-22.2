package fileOperation;

import java.io.File;

public class Eg1 {

	public static void main(String[] args) {


		try {
			File f0=new File("doc1.txt");
			if(f0.createNewFile()) {
				System.out.println("File created");
			}
			else {
				System.out.println("File note created");
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
