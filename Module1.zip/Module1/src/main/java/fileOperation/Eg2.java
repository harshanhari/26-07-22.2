package fileOperation;

import java.io.FileWriter;

public class Eg2 {

	public static void main(String[] args) {


		try {
			FileWriter fWrite=new FileWriter("doc1.txt");
			fWrite.write("A named location used to store related information is referred to as a File.");
		fWrite.close();
		System.out.println("Content is successfully added to the file");
		}catch (Exception e) {
			e.getStackTrace();// TODO: handle exception
		}
		
	}

}
