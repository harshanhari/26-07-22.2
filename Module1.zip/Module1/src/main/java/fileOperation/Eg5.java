package fileOperation;

import java.io.File;

public class Eg5 {

	public static void main(String[] args) {

		File f0 = new File("doc1.txt");
		f0.delete();
		System.out.println("File Deleted");
	}

}
