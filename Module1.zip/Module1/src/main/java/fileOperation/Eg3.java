package fileOperation;

import java.io.File;
import java.util.Scanner;

public class Eg3 {

	public static void main(String[] args) {

		try {
			File f0 = new File("doc1.txt");
			Scanner sc = new Scanner(f0);
			while (sc.hasNextLine()) {
				String dataReader = sc.nextLine();
				System.out.println(dataReader);
			}
			sc.close();
		} catch (Exception e) {
			e.getStackTrace();// TODO: handle exception
		}
	}

}
