package assignment6;

import java.util.Scanner;

public class Qus8 {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter the String : ");
String s1=sc.nextLine();
int leng=s1.length();
for(int i=0;i<leng;i++) {
	System.out.print(i);
}
	}

}
