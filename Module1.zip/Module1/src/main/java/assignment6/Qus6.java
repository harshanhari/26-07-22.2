package assignment6;

import java.util.Scanner;

public class Qus6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);
System.out.print("Enter the string : ");
String s1=sc.nextLine();
System.out.print("Enter the char secuence value : ");
String s2=sc.nextLine();
System.out.println(s1.contains(s2));
}

}
