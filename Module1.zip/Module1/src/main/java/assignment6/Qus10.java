package assignment6;

import java.util.Scanner;

public class Qus10 {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.print("Enter the String : ");
String s1=sc.nextLine();
String s2=s1.trim();
System.out.print("After Trimming : "+s2);
	}

}
