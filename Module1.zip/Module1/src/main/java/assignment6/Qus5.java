package assignment6;

import java.util.Scanner;

public class Qus5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.print("Enter the 1st String : ");
String s1=sc.nextLine();
System.out.print("Enter the 2nd String : ");
String s2=sc.nextLine();
System.out.println("After concatenation "+s1.concat(s2));
	}

}
