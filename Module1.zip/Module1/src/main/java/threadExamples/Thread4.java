package threadExamples;

public class Thread4 implements Runnable {
	public void run() {
		System.out.println("The the thread is running");

	}

	public static void main(String[] args) {
		Runnable r1 = new Thread4();
		Thread t1 = new Thread(r1, "The first Thread");
		t1.start();
		System.out.println(t1.getName());
	}

}
