package threadExamples;

public class TestT8 {

	public static void main(String[] args) {
Thread8 t1=new Thread8("Java T1");
Thread8 t2=new Thread8("Java T2");
System.out.println("The name of t1 is : "+t1.getName());
System.out.println("The name of t2 is : "+t2.getName());
t1.start();
t2.start();
	}

}
