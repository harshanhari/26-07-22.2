package threadExamples;

public class Thread1 extends Thread {
public void run() {
	System.out.println("Thread is running");
}
	

}

