package threadExamples;

public class Thread8 extends Thread{
	public Thread8(String threadName) {
		// TODO Auto-generated constructor stub
	super(threadName);
	}
	public void run() {
		System.out.println("Thread is running...");
	}
}
