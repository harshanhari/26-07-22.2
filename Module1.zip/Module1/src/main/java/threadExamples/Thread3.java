package threadExamples;

public class Thread3 {

	public static void main(String[] args) {
Thread t3=new Thread("My first Thread");
t3.start();
String sr=t3.getName();
System.out.println(sr);
	}

}
