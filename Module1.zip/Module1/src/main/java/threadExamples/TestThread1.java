package threadExamples;

public class TestThread1 {

	public static void main(String[] args) {

		Thread1 t1 = new Thread1();
		t1.start();
		Thread1 t2 = new Thread1();
		t2.start();
		System.out.println(t1.getName());
		System.out.println(t2.getName());
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		Thread1 t3 = new Thread1();
		t3.start();
		System.out.println(t3.getName());
	}

}
