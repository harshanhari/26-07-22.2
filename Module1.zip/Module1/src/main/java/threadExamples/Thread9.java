package threadExamples;

public class Thread9 extends Thread {
public void run() {
	System.out.println(Thread.currentThread().getName());
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Thread9 t1=new Thread9();
Thread9 t2=new Thread9();
t1.start();
t2.start();
	}

}
