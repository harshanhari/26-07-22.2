package threadExamples;

public class Thread7 extends Thread{
public void run() {
	System.out.println("running...");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Thread7 t1=new Thread7();
Thread7 t2=new Thread7();
System.out.println("The name of t1 is : "+t1.getName());
System.out.println("The name of t2 is : "+t2.getName());
t1.start();
t2.start();
t1.setName("fifo");
System.out.println("The new name of t1 is : "+t1.getName());
	}

}
