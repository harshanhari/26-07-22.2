package threadExamples;

public class Thread2 implements Runnable{
public void run() {
	System.out.println("The thread is running");
}
	public static void main(String[] args) {
Thread2 m2=new Thread2();
Thread t2=new Thread(m2);
t2.start();
	}

}
