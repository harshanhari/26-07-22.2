package oops;

public class Student1 {
int id;
String name;
}
