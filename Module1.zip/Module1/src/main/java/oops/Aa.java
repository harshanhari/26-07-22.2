package oops;

public class Aa {
Aa(){
	System.out.println("a");
}
Aa(int x){
	this();
	System.out.println(x);
}
}
