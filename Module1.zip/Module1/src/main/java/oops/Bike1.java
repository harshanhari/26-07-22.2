package oops;

public class Bike1 {
Bike1 (){
	System.out.println("Bike 1 is created");
}
	public static void main(String[] args) {
		Bike1 b=new Bike1();
		
		// TODO Auto-generated method stub

	}

}
