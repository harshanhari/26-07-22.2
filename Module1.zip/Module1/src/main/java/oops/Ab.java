package oops;

public class Ab {
Ab(){
	this(5);
	System.out.println("Hello a");
}
Ab(int x){
	System.out.println(x);
}
}
