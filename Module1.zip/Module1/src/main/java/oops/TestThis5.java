package oops;

public class TestThis5 {

	public static void main(String[] args) {
Aa a=new Aa(10);
	}

}
