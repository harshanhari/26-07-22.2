package oops;

public class TestStudent {

	public static void main(String[] args) {
Student2 s1=new Student2();
s1.insertRecord(101,"Arun");
s1.display();
	}

}
