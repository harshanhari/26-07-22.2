package oops;

public class Student2 {
int id;
String name;
void insertRecord(int i,String n) {
	
	id=i;
	name=n;
}
void display() {
	System.out.println(id);
	System.out.println(name);
}
}
