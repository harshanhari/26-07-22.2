package oops;

public class TestThis6 {

	public static void main(String[] args) {
Ab a=new Ab();

	}

}
