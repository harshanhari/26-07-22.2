package oops;

public class TestStudent1 {

	public static void main(String[] args) {
Student1 s1=new Student1();
System.out.println(s1.id);
System.out.println(s1.name);
	}

}
