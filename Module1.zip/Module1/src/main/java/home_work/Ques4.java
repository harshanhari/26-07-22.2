package home_work;

public class Ques4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Using one System.out.println :- 12 34");
		System.out.print("Using four System.out.print  :- 1");
		System.out.print("2 ");
		System.out.print("3");
		System.out.print("4");
		System.out.printf("\nUsing one System.out.printf  :- 12 34");

	}

}
