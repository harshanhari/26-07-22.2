package home_work;

import java.util.Scanner;

public class Ques9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the numbers ");
		int arr[] = new int[10];
		for (int i = 0; i < 10; i++) {
			arr[i] = sc.nextInt();
		}

		int temp = 0;
		int count = 0;
		for (int i = 0; i < 10; i++) {
			count++;
			if (arr[i] > temp) {
				temp = arr[i];
			}
		}
		System.out.println("Count of number processed         :- " + count);
		System.out.println("The number most recently input is :- " + arr[9]);
		System.out.println("The largest number is             :- " + temp);

	}

}
