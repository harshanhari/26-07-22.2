package home_work;

public class Ques10 {

	public static void main(String[] args) {
		System.out.print("Numbers divisible by 3 are  :- ");
		for (int i = 1; i <= 100; i++) {
			if (i % 3 == 0) {
				System.out.print(i + " ");
			}

		}
		System.out.print("\nNumbers divisible by 5 are  :- ");
		for (int i = 1; i <= 100; i++) {
			if (i % 5 == 0) {
				System.out.print(i + " ");
			}
		}
		System.out.print("\nNumbers divisible by 15 are :- ");
		for (int i = 1; i <= 100; i++) {
			if (i % 15 == 0) {
				System.out.print(i + " ");
			}
		}
	}

}
