package home_work;

public class Ques1 {
	void display() {
		System.out.println("Welcome to the world of java");
	}

	public static void main(String[] args) {
		Ques1 q1 = new Ques1();
		q1.display();
	}

}
