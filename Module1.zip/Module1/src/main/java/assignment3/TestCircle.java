package assignment3;

public class TestCircle {

	public static void main(String[] args) {
Circle c1=new Circle();
System.out.println("The radius of circle is "+c1.getRadius()+" & the area is "+c1.getArea());
Circle c2=new Circle(5.0);
System.out.println("The radius of circle is "+c2.getRadius()+"& the area is "+c2.getArea());
	}

}
