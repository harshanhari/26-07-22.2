package assignment3;

public class EmployeeTest {

	public static void main(String[] args) {
Employee e1=new Employee("Arun","Das", 10000);
Employee e2=new Employee("Harshan","Hari",12000);
System.out.println(e1.getfName()+" "+e1.getlName()+" : "+e1.getmSalary());
System.out.println(e2.getfName()+" "+e2.getlName()+" : "+e2.getmSalary());
System.out.println(e1.getfName()+" "+e1.getlName()+" "+e1.ySal());
System.out.println(e2.getfName()+" "+e2.getlName()+" "+e2.ySal());
System.out.println(e1.getfName()+" "+e1.getlName()+" "+e1.rSal());
System.out.println(e2.getfName()+" "+e2.getlName()+" "+e2.rSal());

	}
}
