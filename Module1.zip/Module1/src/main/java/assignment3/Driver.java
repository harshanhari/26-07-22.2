package assignment3;

public class Driver {
String name;
int age;
Driver(String name,int age){
	this.age=age;
	this.name=name;
}
void drive() {
	System.out.println("the driver is driving");
}
}
