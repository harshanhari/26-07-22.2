package assignment3;

public class Working{

	public static void main(String[] args) {

Car c1=new Car("Benz",1000000);
Car c2=new Car("BMW",8000000);
c1.display();
c2.display();

	}

}
