package assignment3;

//verified pending
public class Employee {
String fName;
String lName;
float mSalary;
public Employee(String fName, String lName, float mSalary) {
	super();
	this.fName = fName;
	this.lName = lName;
	this.mSalary = mSalary;
}
public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public float getmSalary() {
	return mSalary;
}
public void setmSalary(float mSalary) {
	this.mSalary = mSalary;
	if(mSalary<1) {
		mSalary=0.0f;
	}
}
public float ySal() {
	return this.mSalary=mSalary*12;
	
}
public float rSal() {
	return this.mSalary=mSalary+(mSalary*1/10);
	
}

}
