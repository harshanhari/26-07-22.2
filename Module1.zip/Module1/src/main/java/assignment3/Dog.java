package assignment3;

public class Dog {
int age;
String breed,color;
	Dog(int age,String breed,String color){
		this.age=age;
		this.breed=breed;
		this.color=color;
	}
	void bark() {
		System.out.println("the dog is barking");
	}
	void sleep() {
		System.out.println("the dog is sleeping");
	}

}
