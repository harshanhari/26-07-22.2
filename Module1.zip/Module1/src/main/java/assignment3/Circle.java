package assignment3;

public class Circle {

	// verified pending
	double r = 0.0;
	String color = "red";

	Circle() {

	}

	Circle(double r) {
		this.r = r;
	}

	double getRadius() {
		return r;
	}

	double getArea() {
		return r * r * Math.PI;
	}
}
