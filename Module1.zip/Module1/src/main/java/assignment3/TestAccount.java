package assignment3;

import java.util.Scanner;

public class TestAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Account a1=new Account();
Scanner m = new Scanner(System.in);
System.out.println("Enter the Amount");
float money = m.nextFloat();

a1.debit(money);
System.out.println(a1.balance
);	}

}
