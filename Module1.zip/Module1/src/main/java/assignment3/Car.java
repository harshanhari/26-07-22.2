package assignment3;

public class Car {
String model;
double price;
Car(String model,double price){
	this.model=model;
	this.price=price;
	
}
void display() {
	System.out.println(model+" "+price);
}
void start() {
	System.out.println("the car is starting");
}
void Stop() {
	System.out.println("the car is stopping");
}
void move() {
	System.out.println("the car is moving");
}



}
