package assignment3;


public class Account {
	 float balance = 2300000f;

	 void debit(float money) {

		
		if (money > balance) {
			System.out.println("Debit amount exceeded your account balance ");
		} else {
			System.out.println("Money debited successfully");
			balance = balance - money;
		}

	}

}
