package array;

public class Eg1 {

	public static void main(String[] args) {
		int array1[] = new int[5];

		array1[0] = 10;
		array1[1] = 20;
		array1[2] = 30;
		array1[3] = 40;
		array1[4] = 50;
		System.out.println("using for loop");
		for (int i = 0; i < array1.length; i++) {
			System.out.println(array1[i]);
		}

		System.out.println("using for each");
		for (int i : array1) {
			System.out.println(i);
		}

		System.out.println("Declaration,Instanititation,Initialisation of an Array");
		String day[] = { "Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat" };
		for (String days : day) {
			System.out.println(days);
		}
	}
}