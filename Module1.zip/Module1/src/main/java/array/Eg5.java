package array;

public class Eg5 {
static void printArray(int arr[]) {
	for(int i=0;i<arr.length;i++) {
		System.out.println(arr[i]);
	}
}
	public static void main(String[] args) {
	printArray(new int[]{33,4,5,6,7,8});
		// TODO Auto-generated method stub
	
	}

}
