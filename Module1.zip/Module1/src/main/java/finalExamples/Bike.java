package finalExamples;

public class Bike {
final void speed() {
	System.out.println("The speed is 90");
}
}
