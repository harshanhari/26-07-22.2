package finalExamples;

public class Bike20 {
	final int speed;
Bike20(){
	speed=90;
	System.out.println(speed);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
new Bike20();
	}

}
