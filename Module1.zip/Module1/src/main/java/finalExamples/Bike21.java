package finalExamples;

final class Bike21 {

}
