package finalExamples;

public class Bike22 {
	final void run() {
		System.out.println("The bike is running");
	}

}
