package finalExamples;

public class Bike9 {
final int speed=90;
void display() {
	/*speed=120; since final keyword*/
	System.out.println(speed);
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bike9 b=new Bike9();
b.display();
	}

}
