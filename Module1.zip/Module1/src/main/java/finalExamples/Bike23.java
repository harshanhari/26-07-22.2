/*package finalExamples;

public class Bike23 {
int cube(final int n) {
	n=n+2;
	n*n*n;
}
	public static void main(String[] args) {
bike23 b=new Bike23();
b.cube(5);
	}

}*/
