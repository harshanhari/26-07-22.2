/*package finalExamples;

import overriding.Bike21;

public class Honda2 extends Bike21{
void run() {
	System.out.println("Running");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Honda2 h=new Honda2();
h.run();
	}

}
*/