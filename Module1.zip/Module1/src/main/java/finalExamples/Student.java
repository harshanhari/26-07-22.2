package finalExamples;

public class Student {
int id;
String name;
//final String pancardNumber;

}
