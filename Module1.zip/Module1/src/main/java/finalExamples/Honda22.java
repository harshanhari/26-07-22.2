package finalExamples;

public class Honda22 extends Bike22 {

	public static void main(String[] args) {

		new Honda22().run();
	}

}
