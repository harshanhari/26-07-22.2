package finalExamples;

public class Honda extends Bike{
//void speed() since speed is final method
	{
	System.out.println("The speed is 120");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Honda h= new Honda();
h.speed();

	}

}
