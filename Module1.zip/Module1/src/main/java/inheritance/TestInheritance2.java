package inheritance;

public class TestInheritance2 {

	public static void main(String[] args) {
BabyDog b=new BabyDog();
b.weep();
b.bark();
b.eat();
	}

}
