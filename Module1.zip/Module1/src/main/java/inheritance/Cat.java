package inheritance;

public class Cat extends Animal {
void meow() {
	System.out.println("Meowing");
}
}
