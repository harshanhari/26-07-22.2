package inheritance;

public class A {
void a() {
	System.out.println("A");
}
}
