package inheritance;

/*public class C extends A,B {
*/ 
	
	

