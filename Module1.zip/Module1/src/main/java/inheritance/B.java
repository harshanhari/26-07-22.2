package inheritance;

public class B {
void b() {
	System.out.println("B");
}
}
