package inheritance;

public class Animal {
void eat() {
	System.out.println("Eating");
}
}
