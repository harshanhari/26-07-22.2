package inheritance;

public class Employee {
	float salary = 10000f;
	

}
