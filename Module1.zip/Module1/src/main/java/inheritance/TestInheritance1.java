package inheritance;

public class TestInheritance1 {

	public static void main(String[] args) {
Dog d=new Dog();
d.eat();
d.eat();
	}

}
