package controlstatements;

import oops.Student1;

public class TestStudent2 {

	public static void main(String[] args) {
Student1 s1=new Student1();
	}

}
