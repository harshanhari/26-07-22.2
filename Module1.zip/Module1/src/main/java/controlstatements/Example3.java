package controlstatements;

public class Example3 {

	public static void main(String[] args) {
String city = "Delhi";
if(city=="Meroot") {
	System.out.println("city is Meroot");	
}
else if(city=="Agra") {
	System.out.println("city is Agra");
}
else if(city=="Noida") {
	System.out.println("city is Noida");
}
else {
	System.out.println(city);
}

	}

}
