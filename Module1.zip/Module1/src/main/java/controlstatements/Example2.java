package controlstatements;

public class Example2 {

	public static void main(String[] args) {
int a=10,b=5;
if(a+b<a) {
	System.out.println(a+b +" is lessthen "+ a);
}
else {
	System.out.println(a+b +" is greaterthan "+ a);
}
	}

}
