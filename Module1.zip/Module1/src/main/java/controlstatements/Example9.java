package controlstatements;

public class Example9 {

	public static void main(String[] args) {
int num=13;
String output=(num%2==0)?"even":"odd";
System.out.println(output);
	}

}
