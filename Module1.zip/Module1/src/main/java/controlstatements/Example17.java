package controlstatements;

public class Example17 {

	public static void main(String[] args) {
int lev=0;
String levString="Expert";
switch (levString) {
case "Beginner":lev=1;
break;
case "Intermedite":lev=2;
break;
case "Expert":lev=3;
break;
default:System.out.println("Invalid entry");
}
System.out.println("your level is "+lev);
	}

}
