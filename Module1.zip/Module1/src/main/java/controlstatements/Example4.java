package controlstatements;

public class Example4 {

	public static void main(String[] args) {
String address="Delhi,India";
if(address.endsWith("India")) {
	if(address.contains("meerut")) {
		System.out.println("your city is meerut");
	}
	else if(address.contains("agra")) {
		System.out.println("your city is agra");
	}
	else if(address.contains("noida")) {
		System.out.println("your city is noida");
	}
	else {
		System.out.println(address.split(",")[0]);
		
		}
}
	else {
		System.out.println("you are not leaving in india");
	}
	}
}
	


