package controlstatements;

public class Example1 {

	public static void main(String[] args) {
		int a=10,b=5;
		if(a+b>a) {
			System.out.println(a+b + " is greater than "+ a);
		}

	}

}
