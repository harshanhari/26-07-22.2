package controlstatements;

public class Example18 {

	public static void main(String[] args) {
int year=4;
char batch='c';
switch (year) {
case 1:System.out.println("maths,science,english");
break;
case 2:
	switch(batch) {
	case 'c':System.out.println("computer funtamentals,digital electronics");
	break;
	case 'e':System.out.println("electostudy,engin making");
	break;
	case 'm':System.out.println("area making,troubleshoting");
	}
case 3:
	switch(batch) {
	case 'c':System.out.println("operating systems,digitalmarketing");
	break;
	case 'e':System.out.println("evs,nature management");
	break;
	case 'm':System.out.println("robo designing,industries");
	}
case 4:
	switch(batch) {
	case 'c':System.out.println("multimedia,data structure");
	break;
	case 'e':System.out.println("micro electronics,magnets");
	break;
	case 'm':System.out.println("engin instalation,mecha diod");
	}


}
	}

}
