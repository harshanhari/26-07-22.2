package controlstatements;

public class Example13 {

	public static void main(String[] args) {
int age=24,weight=48;
if(age>=18) {
	if(weight>50) {
		System.out.println("you are eligible for donation");
	}
	else {
		System.out.println("you are not eligibile for donation");
	}
}
else {
	System.out.println("you must be aged atleast 18");
}
	}

}
