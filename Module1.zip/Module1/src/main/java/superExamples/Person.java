package superExamples;

public class Person {
int id;
String name;
Person(int id,String name){
	this.id=id;
	this.name=name;
}
}
