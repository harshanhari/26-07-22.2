package superExamples;

public class Animal {
String color="black";
}
