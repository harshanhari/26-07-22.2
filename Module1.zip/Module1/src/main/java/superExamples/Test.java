package superExamples;

public class Test {

	public static void main(String[] args) {

		Dog1 d=new Dog1();
		d.dis();
		
	}

}
