package superExamples;

public class Dog3 extends Animal3{
Dog3(){
	System.out.println("The dog is created");
}
}
