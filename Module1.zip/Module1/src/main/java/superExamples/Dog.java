package superExamples;

public class Dog extends Animal{
String color="White";
void display() {
	System.out.println(color);
System.out.println(super.color);
}
}
