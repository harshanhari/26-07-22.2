package superExamples;

public class Test1 {

	public static void main(String[] args) {
Dog d=new Dog();
d.display();
	}

}
