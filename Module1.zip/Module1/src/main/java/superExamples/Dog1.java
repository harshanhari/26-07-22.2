package superExamples;

public class Dog1 extends Animal1 {
void eat() {
	System.out.println("Eating a bread");
	
}
void bark() {
	System.out.println("Barking");
}
void dis() {
	super.eat();
	bark();
	
}
}
