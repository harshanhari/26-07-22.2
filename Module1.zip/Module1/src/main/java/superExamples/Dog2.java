package superExamples;

public class Dog2 extends Animal2{
	Dog2(){
		super();
		System.out.println("The dog is eating");
	}


}
