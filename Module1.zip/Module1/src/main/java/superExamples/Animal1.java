package superExamples;

public class Animal1 {
void eat() {
	System.out.println("Eating");
}
}
