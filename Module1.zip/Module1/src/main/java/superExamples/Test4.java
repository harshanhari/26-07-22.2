package superExamples;

public class Test4 {

	public static void main(String[] args) {
Emp e1=new Emp(01,"Akesh",10000f);
Emp e2=new Emp(02,"Jai",25000f);
e1.display();
e2.display();
	}

}
