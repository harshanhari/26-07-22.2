package superExamples;

public class Animal2 {
Animal2(){
	System.out.println("The animal is eating");
}
}
