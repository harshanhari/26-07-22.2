package superExamples;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Dog3 d=new Dog3();

	}

}
