package superExamples;

public class Animal3 {
Animal3(){
	System.out.println("The animal is created");
}
}
