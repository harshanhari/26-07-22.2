package assignment1;

public class Ques1 {

	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.println("Harshan Hari");
	}

}


