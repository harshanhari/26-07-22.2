package polymorphism;

public class Circle extends Shape{
void draw() {
	System.out.println("Drawing circle");
}
}
