package polymorphism;

public class Dog3 extends Animal3{
void eat() {
	System.out.println("Eating bread");
}
}
