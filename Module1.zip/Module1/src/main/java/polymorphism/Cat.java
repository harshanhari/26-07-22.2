package polymorphism;

public class Cat extends Animal{
void eat() {
	System.out.println("Eating rat");
}
}
