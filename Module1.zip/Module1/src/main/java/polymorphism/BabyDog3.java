package polymorphism;

public class BabyDog3 extends Dog3{

	public static void main(String[] args) {
Animal3 a=new BabyDog3();
a.eat();
}
	}