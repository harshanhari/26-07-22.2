package polymorphism;

public class Honda extends Bike1 {
int speed =120;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bike1 b=new Honda();
System.out.println(b.speed);
	}

}
