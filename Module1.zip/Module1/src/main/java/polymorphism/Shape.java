package polymorphism;

public class Shape {
void draw() {
	System.out.println("Drawing");
}
}
