package polymorphism;

public class Squre extends Shape{
void draw() {
	System.out.println("Drawing squre");
}
}
