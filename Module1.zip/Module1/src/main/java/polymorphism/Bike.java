package polymorphism;

public class Bike {
void run() {
	System.out.println("Bike is running");
}
}
