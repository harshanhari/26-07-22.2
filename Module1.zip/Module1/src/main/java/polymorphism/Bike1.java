package polymorphism;

public class Bike1 {
int speed=90;
}
