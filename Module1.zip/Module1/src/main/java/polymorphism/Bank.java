package polymorphism;

public class Bank {
float roi() {
	return 0;
}
}
