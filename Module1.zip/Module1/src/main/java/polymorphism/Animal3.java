package polymorphism;

public class Animal3 {
void eat() {
	System.out.println("Eating");
}
}
