package polymorphism;

public class AXIS extends Bank{
float roi() {
	return 9.7f;
}
}
