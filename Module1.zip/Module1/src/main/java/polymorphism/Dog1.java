package polymorphism;

public class Dog1 extends Animal1{
void eat() {
	System.out.println("Eating bread");
}
}
