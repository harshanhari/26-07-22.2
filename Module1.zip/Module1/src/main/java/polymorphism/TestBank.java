package polymorphism;

public class TestBank {

	public static void main(String[] args) {
Bank b;
b=new SBI();
System.out.println("SBI intrest is "+b.roi());
b=new IDIDI();
System.out.println("IDIDI intrest is "+b.roi());
b=new AXIS();
System.out.println("AXIS intrest is "+b.roi());
	}

}
