package polymorphism;

public class IDIDI extends Bank {
float roi() {
	return 8.7f;
}
}
