package polymorphism;

public class Dog extends Animal{
void eat() {
	System.out.println("eating bread");
}
}
