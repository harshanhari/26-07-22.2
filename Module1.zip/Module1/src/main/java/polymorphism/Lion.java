package polymorphism;

public class Lion extends Animal{
void eat() {
	System.out.println("Eating meat");
}
}
