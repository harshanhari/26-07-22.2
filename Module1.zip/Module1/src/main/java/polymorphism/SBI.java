package polymorphism;

public class SBI extends Bank{
float roi() {
	return 7.3f;
}
}
