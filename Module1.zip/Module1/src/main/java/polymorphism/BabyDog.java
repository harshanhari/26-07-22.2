package polymorphism;

public class BabyDog extends Dog1{
void eat() {
	System.out.println("Drinking milk");
}
	public static void main(String[] args) {
Animal1 a1,a2,a3;
a1=new Animal1();
a2=new Dog1();
a3=new BabyDog();
a1.eat();
a2.eat();
a3.eat();

	}

}
