package polymorphism;

public class Splender extends Bike {
void run() {
	System.out.println("The bike is running");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bike b=new Splender();
b.run();
	}

}
