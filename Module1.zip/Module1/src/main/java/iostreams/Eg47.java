package iostreams;

import java.util.Scanner;

public class Eg47 {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("Enter the double value : ");
		double value = input.nextDouble();
		System.out.println("The nextDouble() is : " + value);

	}

}
