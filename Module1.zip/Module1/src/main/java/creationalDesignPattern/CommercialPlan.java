package creationalDesignPattern;

public class CommercialPlan extends Plan {
	void getRate() {
		rate = 10;
	}
}
