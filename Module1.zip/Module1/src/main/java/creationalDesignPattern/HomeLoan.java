package creationalDesignPattern;

public class HomeLoan extends Loan {

	@Override
	void getIntrestRate(double r) {
		rate = r;
	}
}
