package creationalDesignPattern;

public class HDFC extends Bank {
	private final String BNAME;

	public HDFC() {
		BNAME = "HDFC";
	}

	public String getBankName() {
		return BNAME;

	}

}
