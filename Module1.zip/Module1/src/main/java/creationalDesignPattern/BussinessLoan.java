package creationalDesignPattern;

public class BussinessLoan extends Loan {

	@Override
	void getIntrestRate(double r) {
		rate = r;
	}

}
