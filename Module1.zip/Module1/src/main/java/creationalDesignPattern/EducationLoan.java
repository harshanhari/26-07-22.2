package creationalDesignPattern;

public class EducationLoan extends Loan {

	@Override
	void getIntrestRate(double r) {
		rate = r;
	}

}
