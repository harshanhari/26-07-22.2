package creationalDesignPattern;

public class ICICI extends Bank {
	private final String BNAME;

	public ICICI() {
		BNAME = "ICICI";
	}

	public String getBankName() {
		return BNAME;

	}

}
