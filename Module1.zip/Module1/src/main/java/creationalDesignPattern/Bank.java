package creationalDesignPattern;

public abstract class Bank {
	public abstract String getBankName();
}
