package creationalDesignPattern;

public class SBI extends Bank {
	private final String BNAME;

	public SBI() {
		BNAME = "SBI";
	}

	public String getBankName() {
		return BNAME;

	}

}
