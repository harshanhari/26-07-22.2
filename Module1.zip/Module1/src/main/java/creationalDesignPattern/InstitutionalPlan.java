package creationalDesignPattern;

public class InstitutionalPlan extends Plan {
	void getRate() {
		rate = 12;

	}
}
