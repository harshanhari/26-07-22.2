package creationalDesignPattern;

public class DomesticPlan extends Plan {
	void getRate() {
		rate = 9;
	}
}
