package patterns;

public class Exp17 {

	public static void main(String[] args) {
System.out.print("* * * * * *\n");
for(int i=0;i<=5;i++) {
	System.out.println("*         *");
}
System.out.print("* * * * * *");

	}

}
