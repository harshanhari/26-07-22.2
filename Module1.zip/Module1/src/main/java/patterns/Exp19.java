package patterns;

public class Exp19 {

	public static void main(String[] args) {
		for (int x = 0; x <= 7; x++) {
			for (int y = 1; y <= (x * 2) - 1; y++) {
				System.out.print("*");
			}
			System.out.println("");
			for (int z = 5; z >= x; z--) {
				System.out.print(" ");
			}

		}
	}

}
