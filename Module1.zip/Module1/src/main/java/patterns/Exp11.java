package patterns;

public class Exp11 extends Thread {
	public void run() {
		for (int i = 1; i <= 5; i++) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				System.out.println(e);
			}
			System.out.print("*");
		}
	}

	public static void main(String[] args) {
		Exp11 t1 = new Exp11();
		Exp11 t2 = new Exp11();

		t1.start();
	}

}
