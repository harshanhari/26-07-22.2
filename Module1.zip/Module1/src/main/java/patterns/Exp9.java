package patterns;

public class Exp9 {

	public static void main(String[] args) {
		int i, j, k;
		for (i = 1; i <= 9; i++) {
			for (j = i; j < 9; j++) {
				System.out.print(" ");
			}
			for (k = 1; k <= (2 * i - 1); k++) {
				if (k == 1 || k == (2 * i - 1)) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
		for (i = 9; i >= 1; i--) {
			for (j = i; j > 1; j--) {
				System.out.print(" ");
			}
			for (k = 9; k >= (2 / i + 1); k--) {
				if (k == 9 || k == (2 / i + 9)) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
	}

}
