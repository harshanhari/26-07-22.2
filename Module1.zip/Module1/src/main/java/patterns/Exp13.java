package patterns;

public class Exp13 {
public static void main(String[] args) {
	int n=5;
	for(int i=0;i<5;i++) {
		for(int j=n;j>0;j--)
		{
			System.out.print(" ");
		}
		for(int k=0;k<5;k++) {
			System.out.print(" *");
		}
		System.out.println();
		n--;
	}
}
}
