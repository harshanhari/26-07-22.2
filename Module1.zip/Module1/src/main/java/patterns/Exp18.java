package patterns;

public class Exp18 {
	public static void main(String[] args) {
		int val = 1;

		for (int i = 0; i <= 8; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			for (int k = 8; k > i; k--) {
				System.out.print(" ");
			}
			for (int l = 8; l > i; l--) {
				System.out.print("*");
			}
			for (int m = 0; m < val; m++) {

				System.out.print(" ");
			}
			val = val + 2;
			for (int l = 8; l >= i; l--) {
				System.out.print("*");
			}
			for (int k = 8; k >  i; k--) {
				System.out.print(" ");
			}
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}

			System.out.println();

		}

	}
}
