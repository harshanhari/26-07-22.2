package patterns;

public class Exp12 {

	public static void main(String[] args) {

		{
			int n = 11;
			String arr[] = new String[n];
			for (int j = 0; j < 11; j++) {
				for(int i=11;i>j;i--) {
			System.out.print(" ");
				}
				
				for (int k = 0; k < j; k++) {
					System.out.print(" *");
				}
			
				--n;
				System.out.println();
			}
			
		}
		

		{
			System.out.printf(" ");

			int n = 9;
			String arr[] = new String[n];
			for (int j = 0; j < 9; j++) {
				for (int k = 0; k < j; k++) {
					System.out.print(" ");
				}
				for (int i = 0; i < n; i++) {
					arr[i] = " *";
					System.out.print(arr[i] + "");
				}
				--n;
				System.out.println();
			}
		}
		
	}
}
