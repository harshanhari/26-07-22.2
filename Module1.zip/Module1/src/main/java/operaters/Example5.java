package operaters;

public class Example5 {

	public static void main(String[] args) {
System.out.println(10*5/2+8-10*10/2);
	}

}
