package operaters;

public class Example11 {

	public static void main(String[] args) {
int a=5,b=10,c;
c=(a<b)?a:b;
System.out.println(c);

	}

}
