package operaters;

public class Example2 {

	public static void main(String[] args) {
int a=10,b=10;
System.out.println(a++ + ++a);
System.out.println(b++ + b++);

	}

}
